package model;


public class Modelo {
   
    int IdModelo;
    String Modelo;

    public Modelo() {
    }

    public Modelo(int IdModelo, String Modelo) {
        this.IdModelo = IdModelo;
        this.Modelo = Modelo;
    }

    public int getIdModelo() {
        return IdModelo;
    }

    public void setIdModelo(int IdModelo) {
        this.IdModelo = IdModelo;
    }

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

   
  
    
   
}
