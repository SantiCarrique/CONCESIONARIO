package model;


public class Version {
   
    int IdVersion;
    String version;

    public Version() {
    }

    public Version(int IdVersion, String version) {
        this.IdVersion = IdVersion;
        this.version = version;
    }

    public int getIdVersion() {
        return IdVersion;
    }

    public void setIdVersion(int IdVersion) {
        this.IdVersion = IdVersion;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

}