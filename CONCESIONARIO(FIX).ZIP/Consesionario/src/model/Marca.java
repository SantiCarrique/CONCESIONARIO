package model;


public class Marca {
   
    int IdMarca;
    String marca;

    public Marca() {
    }

    public Marca(int IdMarca, String marca) {
        this.IdMarca = IdMarca;
        this.marca = marca;
    }

    public int getIdMarca() {
        return IdMarca;
    }

    public void setIdMarca(int IdMarca) {
        this.IdMarca = IdMarca;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
}
    