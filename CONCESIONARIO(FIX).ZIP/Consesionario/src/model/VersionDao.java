
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class VersionDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
   
    public VersionDao() {
    }
    //Agregar autor
    public boolean agregarVersion(Version version){
        String query = "INSERT INTO version (version) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,version.getVersion());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar la version" + e);
            return false;
        }
    }
    
    //Modificar autor
    public boolean modificarVersion(Version version){
        String query = "UPDATE version SET Version = ? WHERE idVersion = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,version.getVersion());
            pst.setInt(2, version.getIdVersion());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar la version" + e);
            return false;
        }
    }

    //Borrar autor
    public boolean borrarVersion(int id){
        String query = "DELETE FROM version WHERE idVersion = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar la version" + e);
            return false;
        }
    }

    //Listar autor
    public List listarVersion(){
        List<Version> list_version = new ArrayList();
        String query = "SELECT * FROM version ORDER BY version ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Version version = new Version();
                version.setIdVersion(rs.getInt("idVersion"));
                version.setVersion(rs.getString("version"));
                list_version.add(version);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_version;
    }    
    
    //Buscar id de autor
    public int buscarIdVersion(String nombre){
        int id = 0;
        String query = "SELECT idVersion FROM version WHERE version = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idVersion");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de version" + e);
        }
        return id;
    }

}







