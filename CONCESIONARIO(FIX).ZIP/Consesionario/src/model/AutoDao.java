package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class AutoDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public AutoDao() {
    }
    //Agregar auto
    public boolean agregarAuto(Auto auto){
        String query = "INSERT INTO auto (marca, modelo, Kilometros, Anio, precio, puertas, combustible, condicion) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setInt(1,auto.getIdAuto());
            pst.setInt(2,auto.getIdVersion());
            pst.setInt(3,auto.getIdMarca());
            pst.setInt(4,auto.getIdModelo());
            pst.setString(5, auto.getCondicion());
            pst.setString(6, auto.getCombustible());
            pst.setInt(7, auto.getPuertas());
            pst.setDouble(8, auto.getAnio());
            pst.setDouble(9, auto.getPrecio());
            pst.setInt(0, auto.getKilometros());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el libro" + e);
            return false;
        }
    }
    
    //Modificar libro
    public boolean modificarAuto(Auto auto){
        String query = "UPDATE auto SET idmarca = ?, idmodelo = ?, idversion = ?, Anio = ?, Kilometros = ?, combustible = ?,"
                + "precio = ?, condicion = ?, puertas = ?, WHERE idauto = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setInt(1,auto.getIdAuto());
            pst.setInt(2,auto.getIdVersion());
            pst.setInt(3,auto.getIdMarca());
            pst.setInt(4,auto.getIdModelo());
            pst.setString(5, auto.getCondicion());
            pst.setString(6, auto.getCombustible());
            pst.setInt(7, auto.getPuertas());
            pst.setDouble(8, auto.getAnio());
            pst.setDouble(9, auto.getPrecio());
            pst.setInt(0, auto.getKilometros());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el libro" + e);
            return false;
        }
    }

    //Borrar libro
    public boolean borrarAuto(int id){
        String query = "DELETE FROM auto WHERE idauto = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el auto" + e);
            return false;
        }
    }

    //Listar libro
    public List listarAuto(){
        List<Auto> list_autos = new ArrayList();
        String query = "SELECT li.*, au.nombreautor, ed.nombreeditorial, ge.nombregenero FROM libro as li inner join autor as au on li.idautor = au.idautor inner join editorial as ed on li.ideditorial = ed.ideditorial inner join genero as ge on li.idgenero = ge.idgenero ORDER BY titulolibro ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Auto auto = new Auto();
                auto.setIdAuto(rs.getInt("idauto"));
                auto.setIdMarca(rs.getInt("idmarca"));
                auto.setIdVersion(rs.getInt("idversion"));
                auto.setIdModelo(rs.getInt("idmodelo"));
                auto.setAnio(rs.getInt("anios"));
                auto.setPrecio (rs.getDouble("precio"));
                auto.setKilometros (rs.getInt ("kilometros"));
                auto.setCombustible (rs.getString ("combustible"));
                auto.setPuertas(rs.getInt("puertas"));
                auto.setCondicion(rs.getString("condicion"));
                
                list_autos.add(auto);
            }
        
        
        }
        
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_autos;
    }    
}