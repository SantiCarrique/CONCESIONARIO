/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Modelo;
import model.Version;
import model.VersionDao;
import view.Pantalla;

public class VersionControlador implements ActionListener, MouseListener, KeyListener {
    private Version version;
    private VersionDao versionDao;
    private Pantalla panta;

    DefaultTableModel model = new DefaultTableModel();

    public VersionControlador(Version version, VersionDao versionDao, Pantalla panta) {
        this.version = version;
        this.versionDao = versionDao;
        this.panta = panta;
        
        //Botón de registrar autor
        this.panta.btn_Agregar_Version.addActionListener(this);
        //Botón de modificar autor
        this.panta.btn_Modificar_Version.addActionListener(this);
        //Botón de borrar autor
        this.panta.btn_Borrar_Version.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_Limpiar_Version.addActionListener(this);
        
        //Listado de autor
        this.panta.tb_Version.addMouseListener(this);
              
        listarVersiones(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_Agregar_Version){
            //verifica si el campo nombre está vacío
            if(panta.txt_Version.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo version es obligatorio");
            }else{
                //Realiza el agregado
                version.setVersion(panta.txt_Version.getText());
                if(versionDao.agregarVersion(version)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersiones();
                    JOptionPane.showMessageDialog(null, "Se agregó la version");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar la version");
                }
            }
        }else if(e.getSource() == panta.btn_Modificar_Version){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Version.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                version.setIdVersion(Integer.parseInt(panta.txt_Id_Version.getText()));
                version.setVersion(panta.txt_Version.getText());
                if(versionDao.modificarVersion(version)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersiones();
                    JOptionPane.showMessageDialog(null, "Se modificó la version");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar la version");
                }
            }
        }else if(e.getSource() == panta.btn_Borrar_Version){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Version.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_Id_Version.getText());
                if(versionDao.borrarVersion(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersiones();
                    JOptionPane.showMessageDialog(null, "Se eliminó la version");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar la version");
                }
            }
        }else if(e.getSource() == panta.btn_Limpiar_Version){
                limpiarTabla();
                limpiarCampos();
                listarVersiones();    
                panta.btn_Agregar_Version.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Version){
            int row = panta.tb_Version.rowAtPoint(e.getPoint());
            panta.txt_Id_Version.setText(panta.tb_Version.getValueAt(row,0).toString());
            panta.txt_Version.setText(panta.tb_Version.getValueAt(row,1).toString());
            //Deshabilitar
            panta.btn_Agregar_Version.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }
    //Listar todos los autores

public void listarVersiones(){

        panta.cmb_Version.removeAllItems();

        List<Version> list = versionDao.listarVersion();
        model = (DefaultTableModel) panta.tb_Version.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdVersion();
            row[1] = list.get(i).getVersion();
            model.addRow(row);
            panta.cmb_Version.addItem(list.get(i).getVersion());
        }
    }

    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_Id_Version.setText("");
        panta.txt_Version.setText("");
    }

    
}

    

